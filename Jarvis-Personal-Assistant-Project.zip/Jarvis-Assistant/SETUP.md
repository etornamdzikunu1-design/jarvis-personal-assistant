# Setup guide — read this before installing

## What is already prepared
- Jarvis-style chat screen
- Text messages to the AI service
- Spoken AI replies using Expo Speech
- Microphone speech-to-text using a native Android speech-recognition module
- A separate backend so the private AI API key is not exposed in the app

## What still requires your action
I cannot sign in to your Expo account, create a hosting account, accept Android permission prompts, or obtain/pay for an AI API key on your behalf. These are account and security steps.

## Backend configuration
1. Deploy the `backend` folder to a Node.js hosting provider.
2. Set the environment variable `OPENAI_API_KEY` in the hosting provider's private environment settings.
3. Optionally set `OPENAI_MODEL` (default: `gpt-4o-mini`).
4. Confirm the deployed `/health` endpoint returns `{ "ok": true }`.

## Connect the app
Set `EXPO_PUBLIC_JARVIS_API_URL` to the backend's base URL (for example, `https://your-service.example.com`) in the build environment. Do not include `/chat` at the end. Rebuild after changing it.

## Build an Android APK from a cloud build
1. Install dependencies on a computer or cloud development environment: `npm install`.
2. Sign in to Expo: `npx eas login`.
3. Configure the project: `npx eas build:configure`.
4. Build an installable APK: `npx eas build --platform android --profile preview`.
5. Open the build link on your Android tablet and install the APK. Android may ask you to allow installation from that browser.

## Speech recognition note
The microphone feature uses a native module. It needs an EAS-built Android app; it will not work inside ordinary Expo Go. Grant microphone permission when Android asks.

## Device-control limits
This starter does not silently read notifications, send messages, make calls, access other apps, or run a permanent wake-word listener. Android requires explicit permissions and additional native implementation for those features.
