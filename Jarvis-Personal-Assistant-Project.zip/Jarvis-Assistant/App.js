import React, { useEffect, useState } from 'react';
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform, Alert
} from 'react-native';
import * as Speech from 'expo-speech';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';

const API_URL = process.env.EXPO_PUBLIC_JARVIS_API_URL || '';

export default function App() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hello. I am Jarvis. Type a message or tap the microphone to speak.' }
  ]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);

  useSpeechRecognitionEvent('result', (event) => {
    const transcript = event.results?.[0]?.transcript || '';
    if (transcript) setText(transcript);
  });
  useSpeechRecognitionEvent('end', () => setListening(false));
  useSpeechRecognitionEvent('error', (event) => {
    setListening(false);
    Alert.alert('Voice input', event.message || 'Speech recognition could not start. Please try again.');
  });

  useEffect(() => () => { Speech.stop(); }, []);

  async function speak(message) {
    try { await Speech.stop(); Speech.speak(message, { language: 'en-GH', rate: 0.95 }); }
    catch (_) {}
  }

  async function sendMessage(value = text) {
    const prompt = value.trim();
    if (!prompt || busy) return;
    const next = [...messages, { role: 'user', content: prompt }];
    setMessages(next); setText(''); setBusy(true);
    try {
      if (!API_URL) throw new Error('Jarvis AI is not connected yet. The secure AI server URL must be configured first. See SETUP.md.');
      const response = await fetch(`${API_URL.replace(/\/$/, '')}/chat`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.slice(-12) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'The AI service returned an error.');
      const answer = data.reply || 'I could not generate a response.';
      setMessages([...next, { role: 'assistant', content: answer }]);
      await speak(answer);
    } catch (error) {
      const answer = `I couldn't reach my AI service. ${error.message}`;
      setMessages([...next, { role: 'assistant', content: answer }]);
      await speak(answer);
    } finally { setBusy(false); }
  }

  async function startListening() {
    try {
      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Microphone permission', 'Please allow microphone and speech recognition access in Android settings.');
        return;
      }
      setListening(true);
      ExpoSpeechRecognitionModule.start({ lang: 'en-GH', interimResults: true, continuous: false });
    } catch (error) {
      setListening(false);
      Alert.alert('Voice input unavailable', error.message || 'Please use a development build that includes speech recognition.');
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <View><Text style={styles.brand}>J.A.R.V.I.S.</Text><Text style={styles.sub}>PERSONAL AI ASSISTANT</Text></View>
          <View style={styles.status}><View style={styles.dot}/><Text style={styles.statusText}>READY</Text></View>
        </View>
        <ScrollView style={styles.chat} contentContainerStyle={styles.chatContent}>
          {messages.map((m, i) => (
            <View key={i} style={[styles.bubble, m.role === 'user' ? styles.userBubble : styles.aiBubble]}>
              <Text style={styles.role}>{m.role === 'user' ? 'YOU' : 'JARVIS'}</Text>
              <Text style={styles.message}>{m.content}</Text>
            </View>
          ))}
          {busy && <View style={styles.typing}><ActivityIndicator color="#64d8ff"/><Text style={styles.typingText}>Jarvis is thinking…</Text></View>}
        </ScrollView>
        <View style={styles.composer}>
          <TouchableOpacity style={[styles.mic, listening && styles.micOn]} onPress={listening ? () => ExpoSpeechRecognitionModule.stop() : startListening}>
            <Text style={styles.micText}>{listening ? '■' : '🎙'}</Text>
          </TouchableOpacity>
          <TextInput value={text} onChangeText={setText} placeholder="Ask Jarvis anything…" placeholderTextColor="#7891a8"
            style={styles.input} multiline onSubmitEditing={() => sendMessage()} returnKeyType="send"/>
          <TouchableOpacity style={styles.send} onPress={() => sendMessage()} disabled={busy || !text.trim()}>
            <Text style={styles.sendText}>➤</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.footer}>Voice recognition requires the installed Android app build.</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#071522'}, flex:{flex:1}, header:{padding:22,paddingTop:18,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderBottomWidth:1,borderColor:'#17364b'},
  brand:{fontSize:25,fontWeight:'800',letterSpacing:3,color:'#b9efff'},sub:{fontSize:10,letterSpacing:2,color:'#6e9db8',marginTop:4},
  status:{flexDirection:'row',alignItems:'center',gap:7},dot:{width:8,height:8,borderRadius:4,backgroundColor:'#4de0a1'},statusText:{color:'#8ecdb9',fontSize:10,letterSpacing:1},
  chat:{flex:1},chatContent:{padding:16,gap:12},bubble:{padding:14,borderRadius:15,maxWidth:'90%'},aiBubble:{alignSelf:'flex-start',backgroundColor:'#102b3d',borderWidth:1,borderColor:'#1c526d'},userBubble:{alignSelf:'flex-end',backgroundColor:'#15506b'},
  role:{fontSize:10,fontWeight:'800',letterSpacing:1,color:'#71d9ff',marginBottom:6},message:{fontSize:15,lineHeight:22,color:'#e6f4fb'},typing:{flexDirection:'row',alignItems:'center',gap:9,padding:10},typingText:{color:'#8db2c7'},
  composer:{flexDirection:'row',alignItems:'center',gap:9,padding:12,borderTopWidth:1,borderColor:'#17364b'},mic:{width:46,height:46,borderRadius:23,backgroundColor:'#12364c',alignItems:'center',justifyContent:'center'},micOn:{backgroundColor:'#8b2635'},micText:{fontSize:20,color:'white'},
  input:{flex:1,minHeight:46,maxHeight:110,backgroundColor:'#102b3d',borderRadius:14,paddingHorizontal:14,paddingVertical:10,color:'white',fontSize:15},send:{width:46,height:46,borderRadius:23,backgroundColor:'#38bde8',alignItems:'center',justifyContent:'center'},sendText:{fontSize:23,color:'#062033'},footer:{textAlign:'center',fontSize:10,color:'#57788c',paddingBottom:8}
});
