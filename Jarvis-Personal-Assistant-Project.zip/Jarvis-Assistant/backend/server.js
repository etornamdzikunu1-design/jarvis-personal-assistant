import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Jarvis AI' }));
app.post('/chat', async (req, res) => {
  try {
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages.slice(-12).filter(m =>
      ['user', 'assistant'].includes(m.role) && typeof m.content === 'string'
    );
    if (!safeMessages.length) return res.status(400).json({ error: 'Please send a message.' });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are Jarvis, a helpful, clear, practical personal AI assistant. Be honest about your capabilities. Never claim to control the device or perform actions you cannot perform.' },
        ...safeMessages
      ],
      temperature: 0.7
    });
    res.json({ reply: completion.choices[0]?.message?.content || 'I could not generate a reply.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'The AI service had a problem. Check the server configuration and try again.' });
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Jarvis AI backend listening on ${port}`));
