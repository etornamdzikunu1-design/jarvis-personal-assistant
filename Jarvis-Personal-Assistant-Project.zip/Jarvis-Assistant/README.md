# Jarvis Personal Assistant

A React Native / Expo Android app starter with a dark Jarvis-style chat interface, spoken replies, speech-to-text input, and a separate secure AI backend.

## Important
This is a prepared project, not an already-installed app or a finished APK. The AI backend must be deployed and configured with your own OpenAI API key. Keep that key on the backend only; never put it in the Android app.

## Requirements
- Node.js 20+
- Expo SDK 54 compatible environment
- An Expo account for cloud APK builds

## Setup
1. Install dependencies with `npm install`.
2. Start with `npx expo start`.
3. For Android speech recognition, build and install a development/preview APK using EAS. Expo Go does not include every native speech-recognition module.
4. Deploy the `backend` folder to a trusted Node.js host and set `OPENAI_API_KEY` there.
5. Set `EXPO_PUBLIC_JARVIS_API_URL` to the deployed backend URL before building the app.

See `SETUP.md` for the guided steps.
